function [zk, f2v, N] = create_nodes_bndy_refdom_simp(ndim, porder)
%CREATE_NODES_BNDY_REFDOM_SIMP Create nodal distribution and boundary of
%NDIM-dimensional simplex element of order PORDER.
%
%Input arguments
%---------------
%   NDIM, PORDER : See notation.m
%
%Output arguments
%----------------
%   ZK, F2V, N : See notation.m

% Treat 0-dimensional case (boundary of 1D element) as special case
if ndim == 0
    zk = zeros(0, 1); f2v = []; N = [];
    return;
end

% Extract information from input
nf = ndim+1;

% Code me!

end